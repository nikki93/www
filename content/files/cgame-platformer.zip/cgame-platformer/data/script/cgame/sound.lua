cg.wrap_string('sound', 'path')
