dofile('./test/platformer/main.lua')
